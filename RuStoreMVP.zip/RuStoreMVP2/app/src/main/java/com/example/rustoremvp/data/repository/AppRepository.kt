package com.example.rustoremvp.data.repository

import com.example.rustoremvp.data.model.AppModel
import com.example.rustoremvp.data.model.Category
import com.example.rustoremvp.R

class AppRepository {

    private val appsList = listOf(
        AppModel(
            1, "Приложение 1", "Компания А", "Описание приложения 1",
            "Игры", "0+", R.drawable.ic_launcher_foreground,
            listOf(R.drawable.ic_launcher_foreground, R.drawable.ic_launcher_foreground)
        ),
        AppModel(
            2, "Приложение 2", "Компания Б", "Описание приложения 2",
            "Финансы", "6+", R.drawable.ic_launcher_foreground,
            listOf(R.drawable.ic_launcher_foreground)
        ),
        AppModel(
            3, "Приложение 3", "Компания В", "Описание приложения 3",
            "Игры", "12+", R.drawable.ic_launcher_foreground,
            listOf(R.drawable.ic_launcher_foreground)
        )
    )

    fun getApps(): List<AppModel> = appsList

    fun getAppsByCategory(category: String): List<AppModel> =
        appsList.filter { it.category == category }

    fun getCategories(): List<Category> =
        appsList.groupBy { it.category }
            .map { Category(it.key, it.value.size) }
}
