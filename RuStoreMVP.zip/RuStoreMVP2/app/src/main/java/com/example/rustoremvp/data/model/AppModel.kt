package com.example.rustoremvp.data.model

data class AppModel(
    val id: Int,
    val name: String,
    val company: String,
    val description: String,
    val category: String,
    val ageRating: String,
    val icon: Int, // drawable resource
    val screenshots: List<Int> // drawable resources
)
