package com.example.rustoremvp.ui.store

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.rustoremvp.data.model.AppModel
import com.example.rustoremvp.viewmodel.StoreViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StoreScreen(navController: NavController, categoryFilter: String? = null) {
    val viewModel = StoreViewModel()
    val apps = viewModel.apps.collectAsState().value
        .filter { categoryFilter == null || it.category == categoryFilter }

    Scaffold { paddingValues ->
        Column(modifier = Modifier
            .fillMaxSize()
            .padding(paddingValues)
            .padding(16.dp)) {

            Button(
                onClick = { navController.navigate("categories") },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("Выбрать категорию")
            }

            Spacer(Modifier.height(16.dp))

            LazyColumn {
                items(apps) { app ->
                    AppCard(app = app, onClick = { navController.navigate("details/${app.id}") })
                    Spacer(Modifier.height(12.dp))
                }
            }
        }
    }
}

@Composable
fun AppCard(app: AppModel, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(6.dp, RoundedCornerShape(16.dp))
            .clickable { onClick() },
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFE3F2FD))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(64.dp)
                    .clip(CircleShape)
                    .background(Color.White)
                    .shadow(4.dp, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Image(
                    painter = painterResource(id = app.icon),
                    contentDescription = null,
                    modifier = Modifier.size(48.dp)
                )
            }

            Spacer(Modifier.width(16.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(app.name, style = MaterialTheme.typography.titleMedium.copy(fontSize = 20.sp))
                Text(app.company, style = MaterialTheme.typography.bodyMedium.copy(color = Color.Gray))
                Text(
                    "Возраст: ${app.ageRating}",
                    style = MaterialTheme.typography.bodySmall.copy(color = Color(0xFF4A90E2))
                )
            }

            Spacer(Modifier.width(16.dp))

            Button(
                onClick = { /* TODO: PackageInstaller */ },
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4A90E2))
            ) {
                Text("Установить", color = Color.White)
            }
        }
    }
}
