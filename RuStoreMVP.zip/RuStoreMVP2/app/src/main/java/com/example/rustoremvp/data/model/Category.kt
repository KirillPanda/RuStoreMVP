package com.example.rustoremvp.data.model

data class Category(
    val name: String,
    val count: Int
)
