package com.example.rustoremvp.ui.details

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.graphics.Color
import com.example.rustoremvp.data.repository.AppRepository

@Composable
fun AppDetailsScreen(appId: Int, navController: NavController) {
    val app = AppRepository().getApps().firstOrNull { it.id == appId } ?: return

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Button(onClick = { navController.popBackStack() }) {
            Text("Назад")
        }
        Spacer(Modifier.height(16.dp))
        Text(app.name, style = MaterialTheme.typography.headlineMedium)
        Text("Компания: ${app.company}")
        Text("Категория: ${app.category}")
        Text("Возраст: ${app.ageRating}")
        Spacer(Modifier.height(16.dp))
        Text(app.description)

        Spacer(Modifier.height(16.dp))
        Row(modifier = Modifier.horizontalScroll(rememberScrollState())) {
            for (screenshot in app.screenshots) {
                Image(
                    painter = painterResource(screenshot),
                    contentDescription = null,
                    modifier = Modifier
                        .size(200.dp)
                        .padding(end = 12.dp)
                        .shadow(6.dp, RoundedCornerShape(12.dp))
                        .background(Color.White, RoundedCornerShape(12.dp))
                )
            }
        }
    }
}
