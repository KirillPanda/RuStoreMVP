package com.example.rustoremvp.viewmodel

import androidx.lifecycle.ViewModel
import com.example.rustoremvp.data.model.AppModel
import com.example.rustoremvp.data.repository.AppRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

class StoreViewModel : ViewModel() {
    private val repository = AppRepository()

    private val _apps = MutableStateFlow<List<AppModel>>(emptyList())
    val apps: StateFlow<List<AppModel>> = _apps

    init {
        _apps.value = repository.getApps()
    }
}
