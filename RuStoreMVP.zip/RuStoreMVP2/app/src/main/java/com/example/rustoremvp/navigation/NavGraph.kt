package com.example.rustoremvp.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.example.rustoremvp.ui.onboarding.OnboardingScreen
import com.example.rustoremvp.ui.store.StoreScreen
import com.example.rustoremvp.ui.store.CategoriesScreen

@Composable
fun NavGraph(navController: NavHostController) {
    NavHost(navController = navController, startDestination = "onboarding") {
        composable("onboarding") {
            OnboardingScreen(navController = navController)
        }
        composable("store") {
            StoreScreen(navController = navController)
        }
        composable("categories") {
            CategoriesScreen(navController = navController, categories = listOf(
                // пример категорий
            ))
        }
    }
}
