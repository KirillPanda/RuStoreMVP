rootProject.name = "RuStoreMVP2"
include(":app")
